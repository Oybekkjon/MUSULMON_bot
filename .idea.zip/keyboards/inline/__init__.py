from . import Kanal
from . import azolikni_tekshirish
from . import Guruxga_qoshish
