from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

inline_uz = InlineKeyboardMarkup(
     inline_keyboard=[
       [


          InlineKeyboardButton(text='👉GURUXGA QOSHISH👈',switch_inline_query='')
         ]
    ]

)

