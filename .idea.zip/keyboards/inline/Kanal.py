# from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup
#
# inline_uz = InlineKeyboardMarkup(
#     inline_keyboard=[[
#
#
#         InlineKeyboardButton(text='TEZKOR UZ✔️', url="https://t.me/TEZKOR_UZZ_RASMIY"),
#     ]]
#
# )










